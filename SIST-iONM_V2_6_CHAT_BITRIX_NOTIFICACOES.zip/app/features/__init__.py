"""Feature-oriented application modules."""

"""Shared application resources."""

"""Shared web UI resources."""
